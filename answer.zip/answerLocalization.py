from typing import List
import numpy as np
from utils import Particle

### 可以在这里写下一些你需要的变量和函数 ###
COLLISION_DISTANCE = 0.5
MAX_ERROR = 50000
K = 0.3
#分别加在坐标，角度上的高斯噪声的方差
SCALE1=0.15
SCALE2=0.15
#重采样时以1-eps的概率按分布采样，以eps概率全局采样
EPS=0.3
### 可以在这里写下一些你需要的变量和函数 ###


def generate_uniform_particles(walls, N):
    """
    输入：
    walls: 维度为(xxx, 2)的np.array, 地图的墙壁信息，具体设定请看README关于地图的部分
    N: int, 采样点数量
    输出：
    particles: List[Particle], 返回在空地上均匀采样出的N个采样点的列表，每个点的权重都是1/N
    """
    
    xmax=float(np.max(walls[:,0]))
    ymax=float(np.max(walls[:,1]))
    xmin=float(np.min(walls[:,0]))
    ymin=float(np.min(walls[:,1]))
    rng=np.random.default_rng()
    

    all_particles: List[Particle] = []
    for _ in range(N):
        while True:
            #随机生成坐标，朝向
            px=(xmax-xmin)*rng.random()+xmin
            py=(ymax-ymin)*rng.random()+ymin
            ptheta=-np.pi+2*np.pi*rng.random()
            #判断是否合法
            valid=True
            if not(px>=xmin+0.5 and px<=xmax-0.5 and py>=ymin+0.5 and py<=ymax-0.5):
                valid = False
                    
            # for wall in list(walls):
            #     if abs(px-wall[0])<=COLLISION_DISTANCE and abs(py-wall[1])<=COLLISION_DISTANCE:
            #         valid=False
            #         break
            if valid:
                all_particles.append(Particle(px,py,ptheta,1/N))
                break

        #all_particles.append(Particle(1.0, 1.0, 1.0, 0.0))
    
    ### 你的代码 ###
    return all_particles


def calculate_particle_weight(estimated, gt):
    """
    输入：
    estimated: np.array, 该采样点的距离传感器数据
    gt: np.array, Pacman实际位置的距离传感器数据
    输出：
    weight, float, 该采样点的权重
    """
    weight = 1.0
    ### 你的代码 ###
    weight*=np.exp(-K*np.linalg.norm(estimated-gt))
    ### 你的代码 ###
    return weight


def resample_particles(walls, particles: List[Particle]):
    """
    输入：
    walls: 维度为(xxx, 2)的np.array, 地图的墙壁信息，具体设定请看README关于地图的部分
    particles: List[Particle], 上一次采样得到的粒子，注意是按权重从大到小排列的
    输出：
    particles: List[Particle], 返回重采样后的N个采样点的列表
    """
    xmax=float(np.max(walls[:,0]))
    ymax=float(np.max(walls[:,1]))
    xmin=float(np.min(walls[:,0]))
    ymin=float(np.min(walls[:,1]))

    prob_presum=[]
    for particle in particles:
        try:
            prob_presum.append(prob_presum[-1]+particle.get_weight())
        except:
            prob_presum.append(particle.get_weight())
    #把最后一个改成1，避免精度问题导致sum(prob)!=1
    prob_presum[-1]=1.0
    resampled_particles: List[Particle] = []
    rng=np.random.default_rng()

    num = int(len(particles)*(1-EPS))
    for _ in range(num):
        p = rng.random()
        for idx,prob in enumerate(prob_presum):
            #轮盘赌 查找前缀和
            if p <= prob:
                while True:
                    #生成新粒子
                    newx=particles[idx].position[0]+np.random.normal(0.0,SCALE1)
                    newy=particles[idx].position[1]+np.random.normal(0.0,SCALE1)
                    newtheta=particles[idx].theta+np.random.normal(0.0,SCALE2)
                    newweight=1/len(particles)
                    #判断是否合法
                    valid=True
                    if not(newx>=xmin+0.5 and newx<=xmax-0.5 and newy>=ymin+0.5 and newy<=ymax-0.5):
                        valid = False
                    # for wall in list(walls):
                    #     if abs(newx-wall[0])<=COLLISION_DISTANCE and abs(newy-wall[1])<=COLLISION_DISTANCE:
                    #         valid=False
                    #         break
                    if valid:
                        resampled_particles.append(Particle(newx,newy,newtheta,newweight))
                        break
                break
    resampled_particles+=generate_uniform_particles(walls,len(particles)-num)
    
    return resampled_particles

def apply_state_transition(p: Particle, traveled_distance, dtheta):
    """
    输入：
    p: 采样的粒子
    traveled_distance, dtheta: ground truth的Pacman这一步相对于上一步运动方向改变了dtheta，并移动了traveled_distance的距离
    particle: 按照相同方式进行移动后的粒子
    """
    ### 你的代码 ###
    p.theta+=dtheta
    p.position[0]+=traveled_distance*np.cos(p.theta)
    p.position[1]+=traveled_distance*np.sin(p.theta)
    ### 你的代码 ###
    return p

def get_estimate_result(particles: List[Particle]):
    """
    输入：
    particles: List[Particle], 全部采样粒子
    输出：
    final_result: Particle, 最终的猜测结果
    """
    final_result = Particle(0.0,0.0,0.0,0)
    particles.sort(key=Particle.get_weight,reverse=True)
    return particles[0]
    ### 你的代码 ###
    #求加权平均粒子
    for particle in particles:
        final_result.position+=particle.position*particle.get_weight()
        final_result.theta+=particle.theta*particle.get_weight()
    # ### 你的代码 ###
    return final_result